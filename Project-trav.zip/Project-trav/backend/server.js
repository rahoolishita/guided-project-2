const express = require('express');
const { MongoClient } = require('mongodb');
const path = require('path');

const planetsRoutes = require('./routes/planets');
const filmsRoutes = require('./routes/films');
const charactersRoutes = require('./routes/characters');

const app = express();
const port = 3000;

const uri = 'mongodb://localhost:27017';
const dbName = 'swapi';

MongoClient.connect(uri)
  .then(client => {
    const db = client.db(dbName);
    console.log('Connected to MongoDB');

    app.use(express.json());

    // === API Routes ===
    app.use('/api/planets', planetsRoutes(db));
    app.use('/api/films', filmsRoutes(db));
    app.use('/api/characters', charactersRoutes(db));

    // === Serve React App ===
    const publicPath = path.join(__dirname, 'public');
    app.use(express.static(publicPath));

   
  // Safe fallback only for non-API routes
    app.get(/^\/(?!api).*/, (req, res) => {
      res.sendFile(path.join(publicPath, 'index.html'));
    });

    // === Start Server ===
    app.listen(port, () => {
      console.log(` Server running at http://localhost:${port}`);
    });
  })
  .catch(err => {
    console.error(' MongoDB connection failed:', err);
  });
