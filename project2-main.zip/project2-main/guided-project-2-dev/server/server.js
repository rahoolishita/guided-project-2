import express from 'express';
import { promises as fs } from 'fs';
import { MongoClient, ObjectId } from 'mongodb';
import dotenv from 'dotenv';
import cors from 'cors';



dotenv.config();
const url = process.env.MONGO_DB_URL;
const dbName = process.env.MONGO_DB;
const collectionName = process.env.MONGO_DB_COLLECTION;
// const filmsCollection = process.env/MONGO_DB_COLLECTION_FILMS;

const app = express();
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // Middleware to parse JSON bodies
const PORT = 3001;

//get all the films a character is in

app.get('/characters/:id/films', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('characters-data');
        const character = await collection.findOne({ "id": Number(id) });
        const characterFilmsCollection = db.collection('films-characters-data');
        const films = await characterFilmsCollection.find({"character_id": parseInt(id)}).toArray();
       
        
        if(films.length === 0) {
            return res.status(404).send("No films found for this character");
        }
        res.json(films);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This charcter film combo does not exist");
    }
});

// get a character by their id
app.get('/characters/:id', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection(collectionName);
        const character = await collection.findOne({ "id": Number(id) });
        
        if(!character) {
            return res.status(404).send("No character found with that id.");
        }
        res.json(character);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This character does not exist");
    }
});


// Endpoint to read and send JSON file content
app.get('/characters', async (req, res) => {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection(collectionName);
        const characters = await collection.find({}).toArray();
        res.json(characters);
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("No Star Wars for YOU.");
    }
});


//get all the planets in a film

app.get('/films/:id/planets', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('film-data');
        const film = await collection.findOne({ "id": Number(id) });
        const filmPlanetCollection = db.collection('films-planets-data');
        const planets = await filmPlanetCollection.find({"film_id": parseInt(id)}).toArray();
        
        if(planets.length === 0) {
            return res.status(404).send("No planets found in this film");
        }
        res.json(planets);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This film planet combo does not exist");
    }
});

//get all the characters in a film

app.get('/films/:id/characters', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('film-data');
        const film = await collection.findOne({ "id": Number(id) });
        const filmCharacterCollection = db.collection('films-characters-data');
        const characters = await filmCharacterCollection.find({"film_id": parseInt(id)}).toArray();
        
        if(characters.length === 0) {
            return res.status(404).send("No characters found in this film");
        }
        res.json(characters);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This film character combo does not exist");
    }
});

//get a film by the id

app.get('/films/:id', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('films-data');
        const film = await collection.findOne({ "id": Number(id) });
        
        if(!film) {
            return res.status(404).send("No film found with that id.");
        }
        res.json(film);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This film does not exist");
    }
});

//getting the films page

app.get('/films', async (req, res) => {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('films-data');
        const films = await collection.find({}).toArray();
        res.json(films);
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("No films found");
    }
});

//get all the films that took place on a specific planet

app.get('/planets/:id/films', async (req, res) => {
    try {
 
        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('planets-data');
        const planet = await collection.findOne({ "id": Number(id) });
        const filmPlanetCollection = db.collection('films-planets-data');
        const films = await filmPlanetCollection.find({"film_id": parseInt(id)}).toArray();
        if(films.length === 0) {
            return res.status(404).send("No Planets found in this film");
        }
        res.json(films);
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This film planet combo does not exist");
    }
});

//planets and their corresponding characters
app.get('/planets/:id/characters', async (req, res) => {
    try {
 
        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('planets-data');
        const planet = await collection.findOne({ "id": Number(id) });
        const characterCollection = db.collection('character-data');
        const characters = await characterCollection.find({"homeworld": parseInt(id)}).toArray();
        if(characters.length === 0) {
            return res.status(404).send("No characters found in this planet");
        }
        res.json(characters);
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This planet character combo does not exist");
    }
});

//getting planets by their id
// get a character by their id
app.get('/planets/:id', async (req, res) => {
    try {

        const { id } = req.params; 
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('planets-data');
        const planet = await collection.findOne({ "id": Number(id) });
        
        if(!planet) {
            return res.status(404).send("No planet found with that id.");
        }
        res.json(planet);
    
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("This planet does not exist");
    }
});


//getting planets page

app.get('/planets', async (req, res) => {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db(dbName);
        const collection = db.collection('planets-data');
        const planets = await collection.find({}).toArray();
        res.json(planets);
    } catch (err) {
        console.error("Error:", err);
        res.status(500).send("No planets found");
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});