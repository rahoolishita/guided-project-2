import React from 'react';

const Characters = (props) => {
    console.log(props);
    return (
        <div className="card" style={{ flex: '1', minWidth: '300px', maxWidth: '45%' }}>
            <div className="card-body">
                <h5 className="card-title">Character Description</h5>
                <div className="card-text">Name: {props.data.name}</div>
                <div className="card-text">Height: {props.data.height}</div>
                <div className="card-text">Mass: {props.data.mass}</div>
                <div className="card-text">Skin Color: {props.data.skin_color}</div>
                <div className="card-text">Eye Color: {props.data.eye_color}</div>
                <div className="card-text">Gender: {props.data.gender}</div>
            </div>
        </div>
    );
};

export default Characters;
