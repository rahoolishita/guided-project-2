import Characters from "./Characters";

const Home = (props) => {
    return (
        <div className="card-container" style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
            <h1>Home</h1>
        </div>
    );
};

export default Home;