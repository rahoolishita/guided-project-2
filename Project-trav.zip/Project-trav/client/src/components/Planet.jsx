import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import '../css/style.css';

function Planet() {
  const { id } = useParams();
  const [planet, setPlanet] = useState(null);
  const [films, setFilms] = useState([]);
  const [characters, setCharacters] = useState([]);

  useEffect(() => {
    fetch(`/api/planets/${id}`).then(res => res.json()).then(setPlanet);
    fetch(`/api/planets/${id}/films`).then(res => res.json()).then(setFilms);
    fetch(`/api/planets/${id}/characters`).then(res => res.json()).then(setCharacters);
  }, [id]);

  if (!planet) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <h2>{planet.name}</h2>
      <p><strong>Climate:</strong> {planet.climate}</p>

      <div className="section">
        <h4>Films</h4>
        <ul>
          {films.map(f => (
            <li key={f._id}><Link to={`/film/${f._id}`}>{f.title}</Link></li>
          ))}
        </ul>
      </div>

      <div className="section">
        <h4>Characters</h4>
        <ul>
          {characters.map(c => (
            <li key={c._id}><Link to={`/character/${c._id}`}>{c.name}</Link></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Planet;