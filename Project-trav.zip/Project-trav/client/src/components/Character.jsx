import { useParams, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import '../css/style.css';

function Character() {
  const { id } = useParams();
  const [character, setCharacter] = useState(null);
  const [planet, setPlanet] = useState(null);
  const [films, setFilms] = useState([]);

  useEffect(() => {
    fetch(`/api/characters/${id}`).then(res => res.json()).then(setCharacter);
    fetch(`/api/characters/${id}/planet`).then(res => res.json()).then(setPlanet);
    fetch(`/api/characters/${id}/films`).then(res => res.json()).then(setFilms);
  }, [id]);

  if (!character) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <h2>{character.name}</h2>

      <div className="section">
        <h4>Homeworld</h4>
        <p>{planet && <Link to={`/planet/${planet._id}`}>{planet.name}</Link>}</p>
      </div>

      <div className="section">
        <h4>Films</h4>
        <ul>
          {films.map(f => (
            <li key={f._id}><Link to={`/film/${f._id}`}>{f.title}</Link></li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Character;